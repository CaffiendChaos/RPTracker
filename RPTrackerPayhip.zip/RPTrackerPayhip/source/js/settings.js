const deployID = 'AKfycbxh_aY9YsIZNeX0kVPXu_37uhfFNrJlqPrtjbpAbpdD9yp6aeUOMhYNwHiE7DL_LydZ';
const sheetID = `13ylRx1wxQ0wgBV5gABvfG3vYfq-n3NvEdyqxzcF7DpI`;
const oldSheetID = ``;
const successMessage = `<p class="fullWidth">Submission successful!</p>
<button onclick="location.reload();" type="button" class="fullWidth submit">Back to form</button>`;
const threadTags = ["vital", "priority", "rapidfire", "romantic", "family", "friends", "coworkers"];
const chartColors = ['#cf86a8', '#84a9d1', '#af88ba', '#85b8b5', '#b6aa79', '#c9986e', '#84ad85', '#ba7878'];